import Logo from './images/react-logo.png'; 

const ImportImage = () => { 
  return <img src={Logo} alt="React Logo" className="App-logo"/> 
}; 

export default ImportImage;