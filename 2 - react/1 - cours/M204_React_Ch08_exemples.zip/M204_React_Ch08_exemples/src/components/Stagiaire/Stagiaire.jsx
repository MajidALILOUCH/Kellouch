import React, { Component } from 'react'; 
import styles from './Stagiaire.module.css'; 
 
export default class Stagiaire extends Component { 
  render() { 
    return ( 
      <>
        <div className={styles.myclass}>Stagiaire</div> 
        <div className={styles.stagiaire}>
          <h2 className={styles.titre}>RADI Salma</h2>
          <p className={styles.texte}>Stagiaire en développement</p>
        </div>
      </>
    ); 
  } 
} 