import styled from "styled-components";

// Button Dark
const ButtonDark = styled.button`
  background: black;
  color: white;
  padding: 1rem 1.75rem;
  border: none;
  border-radius: 0;
  &:hover {
    background: white;
    color: black;
  }
`;

// Button Standard
const StyledButton = styled.button`
  // Style de base
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  border-radius: 0.25rem;
  cursor: pointer;
  transition: all 0.15s ease-in-out;

  // Primary Button
  background-color: #0d6efd;
  color: white;
  border: 1px solid #0d6efd;

  &:hover {
    background-color: #0b5ed7;
    border-color: #0a58ca;
  }

  &:active {
    background-color: #0a58ca;
    border-color: #0a53be;
  }

  // Disabled state
  &:disabled {
    opacity: 0.65;
    pointer-events: none;
  }
`;

// Button primary
const PrimaryButton = styled.button`
  padding: 0.375rem 0.75rem;
  background-color: #0d6efd;
  color: white;
  border: 1px solid #0d6efd;
  border-radius: 0.25rem;
  cursor: pointer;

  &:hover {
    background-color: #0b5ed7;
  }
`;

// Button secondary
const SecondaryButton = styled.button`
  padding: 0.375rem 0.75rem;
  background-color: #6c757d;
  color: white;
  border: 1px solid #6c757d;
  border-radius: 0.25rem;
  cursor: pointer;

  &:hover {
    background-color: #5c636a;
  }
`;

// Button success
const SuccessButton = styled.button`
  padding: 0.375rem 0.75rem;
  background-color: #198754;
  color: white;
  border: 1px solid #198754;
  border-radius: 0.25rem;
  cursor: pointer;

  &:hover {
    background-color: #157347;
  }
`;

const StyledButtons = () => {
  return (
    <div>
      <ButtonDark>Dark</ButtonDark>
      <hr />
      <StyledButton>Standard</StyledButton>
      <PrimaryButton>Primary</PrimaryButton>
      <SecondaryButton>Secondary</SecondaryButton>
      <SuccessButton>Success</SuccessButton>
    </div>
  );
};



export default StyledButtons;
