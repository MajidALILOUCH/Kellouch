import React, { Component } from 'react'; 
import styles from './Personne.module.css'; 
 
export default class Personne extends Component { 
  render() { 
    return ( 
      <>
        <div className={styles.myclass}>Personne</div> 
        <div className={styles.personne}>
          <h2 className={styles.titre}>Salman Ali</h2>
          <p className={styles.texte}>Développeur Senior</p>
        </div> 
      </>
    ); 
  } 
} 