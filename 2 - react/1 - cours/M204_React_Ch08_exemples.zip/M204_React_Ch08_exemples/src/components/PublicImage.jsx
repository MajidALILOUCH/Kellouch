
const PublicImage = () => {
  return <img src={process.env.PUBLIC_URL + "/images/react-logo.png"} alt="React Logo" className="App-logo"/>
};

export default PublicImage;