
const FunctionRequire = () => {
  const logo_png = require('./images/react-logo.png');  
  // Pour  les fichiers svg, il faut ajouter .default
  // require() renvoie un objet module avec une propriété default
  const logo_svg = require('./images/react-logo.svg').default;
  return <>
  <img src={logo_png} alt="React Logo png" className='App-logo'/>  
  <img src={logo_svg} alt="React Logo png" className='App-logo'/>
  </>
  
};

export default FunctionRequire;