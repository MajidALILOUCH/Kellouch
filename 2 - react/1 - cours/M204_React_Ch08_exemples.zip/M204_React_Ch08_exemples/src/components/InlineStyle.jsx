
const InlineStyle = () => {
  const divStyle = {
    backgroundColor: 'lightblue',
    border: '1px solid darkblue',
    padding: '10px',
    fontSize: '20px',
    margin: '10px',
    width: '100vw',
    textAlign: 'center',
  };
  return <div style={divStyle}>
     <button style={{color: 'white', backgroundColor: 'blue', border: 'none'}}>Click Me</button>
  </div>
};

export default InlineStyle;