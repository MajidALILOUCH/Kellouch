import ImportImage from './components/ImportImage';
import FunctionRequire from './components/FunctionRequire';
import PublicImage from './components/PublicImage';
import InlineStyle from './components/InlineStyle';
import './App.css';
import Personne from './components/Personne/Personne';
import Stagiaire from './components/Stagiaire/Stagiaire';
import StyledButtons from './components/StyledButtons';
function App() {
  return (
    <div className="App">
      {/*  */}
      <h1>Importer Logo</h1>
      <ImportImage />
       
      <hr />
      <h1>Importer Logo avec require</h1>
      <FunctionRequire />
      
      <hr />
      <h1>Importer Logo avec process.env.PUBLIC_URL</h1>
      <PublicImage />
     
      <hr />
      <h1>Inline Style</h1>
      <InlineStyle />
      <hr />
      <h1>CSS Modules</h1>
      <Personne />
      <Stagiaire />
      <hr />
      
      <h1>StyledButtons</h1>
      <StyledButtons />  
      {/**/}
    </div>
  );
}

export default App;
